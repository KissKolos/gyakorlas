<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
</head>
<body>
    <?php require_once "menu.php"; ?>
    
</body>
</html>