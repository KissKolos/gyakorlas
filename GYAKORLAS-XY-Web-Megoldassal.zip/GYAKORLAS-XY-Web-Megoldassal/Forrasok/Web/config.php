<?php
$CONFIG = array(
    "host" => "localhost",
    "port" => 3306,
    "charset" => "utf8",
    "dbname" => "",
    "user" => "",
    "pwd" => ""
);

?>