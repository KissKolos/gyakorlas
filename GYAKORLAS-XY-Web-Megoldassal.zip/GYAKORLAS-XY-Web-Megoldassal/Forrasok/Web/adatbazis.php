<?php
require_once "config.php";
class adatbazis
{
    private $connection_string, $username, $password;
    public $pdo;

    public function __construct()
    {
        global $CONFIG;
        try 
        {
            $host = $CONFIG['host'];
            $port = $CONFIG['port'];
            $dbname = $CONFIG['dbname'];
            $charset = $CONFIG['charset'];
            $this->connection_string = "mysql:host=$host;dbname=$dbname;port=$port;charset=$charset;";
            $this->username = $CONFIG['user'];
            $this->password = $CONFIG['pwd'];
        } 
        catch (PDOException $err) 
        {
            throw new Exception("Adatbázis hiba: ".$err->getMessage(),$err->getCode());
        }
    }

    public function Open() : void
    {
        try 
        {
            $options = [
                PDO::ATTR_EMULATE_PREPARES   => false, 
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC 
            ];
            $this->pdo = new PDO($this->connection_string,$this->username,$this->password,$options);
            if($this->pdo === false) throw new PDOException("Nem sikerült csatlakozni az adatbázishoz!");
        } 
        catch (PDOException $err) 
        {
            throw new Exception("Adatbázis hiba: ".$err->getMessage(),$err->getCode());
        }
    }

    public function Close() : void
    {
        try 
        {
            $this->pdo = null;
        } 
        catch (PDOException $err) 
        {
            throw new Exception("Adatbázis hiba: ".$err->getMessage(),$err->getCode());
        }
    }

    public function TransactionStart() : void
    {
        $this->pdo->beginTransaction();
    }

    public function TransactionEnd() : void
    {
        $this->pdo->commit();
    }

    public function TransactionBack() : void
    {
        $this->pdo->rollBack();
    }

    private function Query($mode,$sql,$params=null) : array
    {
        try 
        {
            if($params == null)
            {
                $stmt = $this->pdo->query($sql,$mode);
                return $stmt->fetchAll($mode);
            }
            else
            {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($params);
                return $stmt->fetchAll($mode);
            }
        } catch (PDOException $err) 
        {
            throw new Exception("Adatbázis hiba: ".$err->getMessage(),$err->getCode());
        }
    } 
    public function QueryArrayAssoc($sql, $params=null) : array
    {
        return $this->Query(PDO::FETCH_ASSOC,$sql,$params);
    }

    public function QueryArrayNum($sql, $params=null) : array
    {
        return $this->Query(PDO::FETCH_NUM,$sql,$params);
    }

    public function QueryArrayBoth($sql, $params=null) : array
    {
        return $this->Query(PDO::FETCH_BOTH,$sql,$params);
    }

    public function QueryArrayObj($sql, $params=null) : array
    {
        return $this->Query(PDO::FETCH_OBJ,$sql,$params);
    }

    public function QueryArrayJSon($sql, $params=null) : string
    {
        return json_encode($this->Query(PDO::FETCH_ASSOC,$sql,$params));
    }

    private function NoneQueryCommand($command,$sql,$params=null) : int|bool
    {
        try 
        {
            $ret = false;
            if($params == null)
            {
                $stmt = $this->pdo->query($sql);
            }
            else
            {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($params);
            }
            switch(strtoupper($command))
            {
                case "INSERT":
                    $ret = $this->pdo->lastInsertId(); 
                    break;
                case "UPDATE":
                case "DELETE":
                        $ret = $stmt->rowCount();
                    break;
                default: 
                    $ret = $stmt !== false;
                    break;
            }
            return $ret;
        } 
        catch (PDOException $err) 
        {
            throw new Exception("Adatbázis hiba: ".$err->getMessage(),$err->getCode());
        }
    } 

    public function Insert($sql,$params=null) : int|bool
    {
        $sv = strtoupper(substr(trim($sql),0,6));
        if($sv == "INSERT")
            return $this->NoneQueryCommand($sv,$sql,$params);
        else
            throw new Exception("Nem INSERT jellegű lekérdezés!");
    }

    public function Update($sql,$params=null) : int|bool
    {
        $sv = strtoupper(substr(trim($sql),0,6));
        if($sv == "UPDATE")
            return $this->NoneQueryCommand($sv,$sql,$params);
        else
            throw new Exception("Nem UPDATE jellegű lekérdezés!");
    }    

    public function Delete($sql,$params=null) : int|bool
    {
        $sv = strtoupper(substr(trim($sql),0,6));
        if($sv == "DELETE")
            return $this->NoneQueryCommand($sv,$sql,$params);
        else
            throw new Exception("Nem DELETE jellegű lekérdezés!");
    }    

    public function NoneQuery($sql,$params=null) : int|bool
    {
        $command = substr(trim($sql),0,6); // INSERT, UPDATE, DELETE
        return $this->NoneQueryCommand($command,$sql,$params);
    }

}

?>