<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <?php require_once "menu.php"; ?>

    <div class="container">
        <h1 class="mt-3">Pályázatok (json)</h1>

        <?php
            $url = "http://localhost/tanulo/gyak13ip/www/palyazatok_api.php";
            $sv = file_get_contents($url);
            echo $sv;
        ?>
    </div>
    
    
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>