<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <?php
        if($_SERVER['REQUEST_METHOD'] === "POST" && count($_POST) == 1 && isset($_POST['id']) && (int) $_POST['id'] > 0)
        {
            $id = (int) $_POST['id'];
            $post_data = array('id' => $id);
            $url = "http://localhost/tanulo/gyak13ip/www/torles_api.php";
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $res = curl_exec($ch);
            curl_close($ch);
            var_dump($res);
            header("location:szamlak.php");
            return;
        }
    ?>

    <?php require_once "menu.php"; ?>

    <div class="container">
        <h1 class="mt-3">Törlés</h1>

        <form action="torles.php" method="post">
            Pályázat azonosítója:
            <input type="number" name="id">
            <input type="submit" value="OK - Töröl">
        </form>

    </div>
    
    
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>