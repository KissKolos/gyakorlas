<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <?php
        if($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['p_id'],$_POST['k_id'],$_POST['szszam'],$_POST['datum'],$_POST['ertek']))
        {
            $p_id = $_POST['p_id'];
            $k_id = $_POST['k_id'];
            $szszam = $_POST['szszam'];
            $datum = $_POST['datum'];
            $ertek = $_POST['ertek'];
            $sql = "INSERT INTO szamla (szamlaszam, datum, ertek, palyazatId, koltsegtipusId) VALUES ('$szszam', '$datum', '$ertek', '$p_id', '$k_id')";
            require_once "connect.php";
            $kapcs = connect();
            $kapcs->query($sql);
            header("location:szamlak.php?id=$p_id");
            return;
        }
    ?>

    <?php require_once "menu.php"; ?>

    <div class="container">
        <h1 class="mt-3">Új számla</h1>

        <?php
            $url = "http://localhost/tanulo/gyak13ip/www/palyazatok_api.php";
            $sv = file_get_contents($url);
            $palyazatok = json_decode($sv);

            $url = "http://localhost/tanulo/gyak13ip/www/koltsegtipusok_api.php";
            $sv = file_get_contents($url);
            $koltsegtipusok = json_decode($sv);
        ?>

        <form method="post" action="uj.php">
            Pályázat:
            <select name="p_id" required>
                <option value="">--- válasszon pályázatot ---</option>
                <?php
                    foreach($palyazatok as $p)
                    {
                        $txt = $p->id.' - '.$p->tervezetA.' - '.$p->tervezetC;
                        echo '<option value="'.$p->id.'">'.$txt.'</option>';
                    }
                ?>
            </select>
            <br><br>
            Költségtípus:
            <select name="k_id" required>
                <option value="">--- válasszon költségtípust ---</option>
                <?php
                    foreach($koltsegtipusok as $k)
                    {
                        echo '<option value="'.$k->id.'">'.$k->megnevezes.'</option>';
                    }
                ?>
            </select>
            <br><br>
            Szánlaszám: <input type="text" name="szszam" required>
            <br><br>
            Dátum (éééé-hh-nn): <input type="text" name="datum" required>
            <br><br>
            Érték: <input type="number" name="ertek" required>
            <br><br>
            <input type="submit" value="OK- Tárol">
        </form>

    </div>
    
    
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>