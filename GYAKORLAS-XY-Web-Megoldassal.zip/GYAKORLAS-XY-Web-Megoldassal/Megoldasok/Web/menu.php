
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php"><i class="fa-solid fa-house"></i>Főoldal</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">

          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="koltsegtipusok.php">Költségtípusok (json)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="palyazatok1.php">Pályázatok (json)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="palyazatok2.php">Pályázatok (táblázat)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="szamlak.php">Számlák (szűréssel)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="torles.php">Törlés</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="uj.php">Új számla</a>
          </li>

        </ul>
      </div>
    </div>
  </nav>
