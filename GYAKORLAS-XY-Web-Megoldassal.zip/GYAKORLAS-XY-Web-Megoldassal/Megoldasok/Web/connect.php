<?php
function connect()
{
    return new mysqli("localhost","root","","palyazatok");
}
?>