<?php
if($_SERVER['REQUEST_METHOD'] === "GET" && count($_GET) == 1 && isset($_GET['id']) && (int) $_GET['id'] > 0)
{
    $id = (int) $_GET['id'];
    require_once "connect.php";
    $kapcs = connect();
    $sql = "SELECT s.szamlaszam, s.datum, s.ertek, k.megnevezes
            FROM szamla AS s
            INNER JOIN koltsegtipus AS k ON k.id = s.koltsegtipusId
            WHERE s.palyazatId = '$id'
            ORDER BY 4 ASC, 3 DESC";
    $sorok = $kapcs->query($sql);
    $kapcs->close();
    $tomb = [];
    while($sor = $sorok->fetch_assoc())
    {
        $tomb[] = $sor;
    }
    header("Content-type: application/json; charset=utf-8");
    http_response_code(200);
    echo json_encode($tomb);
}
else
{
    http_response_code(400);
}
?>
