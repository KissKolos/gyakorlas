<?php
if($_SERVER['REQUEST_METHOD'] === "POST" && count($_POST) == 1 && isset($_POST['id']) && (int) $_POST['id'] > 0)
{
    $id = (int) $_POST['id'];
    require_once "connect.php";
    $kapcs = connect();
    $sql = "DELETE FROM szamla WHERE palyazatId = '$id'";
    $kapcs->query($sql);
    $sql = "DELETE FROM palyazat WHERE id = '$id'";
    $kapcs->query($sql);
    $kapcs->close();
    header("Content-type: application/json; charset=utf-8");
    http_response_code(200);
    $tomb=[];
    $tomb['siker'] = "true";
    echo json_encode($tomb);
}
else
{
    http_response_code(400);
}
?>
