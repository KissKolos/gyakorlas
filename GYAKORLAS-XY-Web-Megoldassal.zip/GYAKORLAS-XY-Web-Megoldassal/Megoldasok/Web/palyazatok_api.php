<?php
if($_SERVER['REQUEST_METHOD'] === "GET" && count($_GET) == 0)
{
    require_once "connect.php";
    $kapcs = connect();
    $sql = "SELECT id, tervezetA, tervezetC FROM palyazat ORDER BY 1";
    $sorok = $kapcs->query($sql);
    $kapcs->close();
    $tomb = [];
    while($sor = $sorok->fetch_assoc())
    {
        $tomb[] = $sor;
    }
    header("Content-type: application/json; charset=utf-8");
    http_response_code(200);
    echo json_encode($tomb);
}
else
{
    http_response_code(400);
}
?>
