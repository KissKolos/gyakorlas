<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <?php require_once "menu.php"; ?>

    <div class="container">
        <h1 class="mt-3">Pályázatok (táblázat)</h1>

        <?php
            $url = "http://localhost/tanulo/gyak13ip/www/palyazatok_api.php";
            $sv = file_get_contents($url);
            $adatok = json_decode($sv);
            //print_r($adatok);
        ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tervezet-A</th>
                    <th>Tervezet-C</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($adatok as $sor)
                    {
                        echo '
                            <tr>
                                <td>'.$sor->id.'</td>
                                <td>'.$sor->tervezetA.'</td>
                                <td>'.$sor->tervezetC.'</td>
                            </tr>';
                    }
                ?>
            </tbody>
        </table>

    </div>
    
    
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>