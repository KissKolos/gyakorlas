<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <?php require_once "menu.php"; ?>

    <div class="container">
        <h1 class="mt-3">Számlák (szűréssel)</h1>

        <?php
            $url = "http://localhost/tanulo/gyak13ip/www/palyazatok_api.php";
            $sv = file_get_contents($url);
            $palyazatok = json_decode($sv);

            if(isset($_GET['id']) && trim($_GET['id']) !== "")
            {
                $id = (int) $_GET['id'];
                $url = "http://localhost/tanulo/gyak13ip/www/szamlak_api.php?id=".$id;
                $sv = file_get_contents($url);
                $szamlak = json_decode($sv);
            }
            else
            {
                $szamlak = [];
            }
        ?>

        <form action="szamlak.php" method="get">
            <select name="id" onchange="submit()">
                <option value="">--- válasszon pályázatot ---</option>
                <?php
                    foreach($palyazatok as $p)
                    {
                        $s = isset($_GET['id']) && $_GET['id'] == $p->id ? "selected" : "";
                        $text = $p->id.' - '.$p->tervezetA.' - '.$p->tervezetC;
                        echo '<option value="'.$p->id.'" '.$s.'>'.$text.'</option>';
                    }
                ?>
            </select>
        </form>

        <?php
        if(count($szamlak) == 0)
        {
            echo '<h3>Nincs számla / Nem választott pályázatot!</h3>';
            return;
        }
        ?>

        <table class="table table-bordered table-hover table-stripped table-success mt-3">
            <thead>
                <tr>
                    <th>Számlaszám</th>
                    <th>Dátum</th>
                    <th>Érték</th>
                    <th>Költség megnevezése</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($szamlak as $sor)
                    {
                        echo '
                            <tr>
                                <td>'.$sor->szamlaszam.'</td>
                                <td>'.$sor->datum.'</td>
                                <td>'.$sor->ertek.'</td>
                                <td>'.$sor->megnevezes.'</td>
                            </tr>
                        ';
                    }
                ?>
            </tbody>
        </table>



    </div>
    
    
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>