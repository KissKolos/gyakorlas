<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYAKORLÁS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <?php require_once "menu.php"; ?>

    <div class="container">
        <h1 class="mt-3">Főoldal</h1>
        <h2>Gyakorlás (2025.05.12.)</h2>
        <table class="table table-hover table-stripped table-bordered table-primary">
            <tr>
                <td>Tanuló neve:</td>
                <td>Citrom Cecil</td>
            </tr>
            <tr>
                <td>Osztálya:</td>
                <td>15.Zs</td>
            </tr>
            <tr>
                <td>Születési dátuma:</td>
                <td>2005.05.05.</td>
            </tr>
            <tr>
                <td>Anyja neve:</td>
                <td>Eper Emma</td>
            </tr>
        </table>
    </div>
    
    
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>