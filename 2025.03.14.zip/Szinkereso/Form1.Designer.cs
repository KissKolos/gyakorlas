﻿namespace Szinkereso
{
    partial class frmSzinkereso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnKever = new System.Windows.Forms.Button();
            this.btnRejt = new System.Windows.Forms.Button();
            this.btnUj = new System.Windows.Forms.Button();
            this.btnKilep = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(26, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 50);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(26, 68);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 600);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(232, 68);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(50, 600);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(288, 68);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(50, 600);
            this.panel4.TabIndex = 3;
            // 
            // btnKever
            // 
            this.btnKever.Location = new System.Drawing.Point(232, 12);
            this.btnKever.Name = "btnKever";
            this.btnKever.Size = new System.Drawing.Size(50, 23);
            this.btnKever.TabIndex = 4;
            this.btnKever.Text = "Ke&ver";
            this.btnKever.UseVisualStyleBackColor = true;
            this.btnKever.Click += new System.EventHandler(this.btnKever_Click);
            // 
            // btnRejt
            // 
            this.btnRejt.Location = new System.Drawing.Point(232, 39);
            this.btnRejt.Name = "btnRejt";
            this.btnRejt.Size = new System.Drawing.Size(50, 23);
            this.btnRejt.TabIndex = 5;
            this.btnRejt.Text = "&Rejt";
            this.btnRejt.UseVisualStyleBackColor = true;
            this.btnRejt.Click += new System.EventHandler(this.btnRejt_Click);
            // 
            // btnUj
            // 
            this.btnUj.Location = new System.Drawing.Point(288, 12);
            this.btnUj.Name = "btnUj";
            this.btnUj.Size = new System.Drawing.Size(50, 23);
            this.btnUj.TabIndex = 6;
            this.btnUj.Text = "Ú&j";
            this.btnUj.UseVisualStyleBackColor = true;
            this.btnUj.Click += new System.EventHandler(this.btnUj_Click);
            // 
            // btnKilep
            // 
            this.btnKilep.Location = new System.Drawing.Point(288, 39);
            this.btnKilep.Name = "btnKilep";
            this.btnKilep.Size = new System.Drawing.Size(50, 23);
            this.btnKilep.TabIndex = 7;
            this.btnKilep.Text = "&Kilépés";
            this.btnKilep.UseVisualStyleBackColor = true;
            this.btnKilep.Click += new System.EventHandler(this.btnKilep_Click);
            // 
            // frmSzinkereso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 684);
            this.Controls.Add(this.btnKilep);
            this.Controls.Add(this.btnUj);
            this.Controls.Add(this.btnRejt);
            this.Controls.Add(this.btnKever);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmSzinkereso";
            this.Text = "Színkereső";
            this.TransparencyKey = System.Drawing.SystemColors.Control;
            this.Load += new System.EventHandler(this.frmSzinkereso_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnKever;
        private System.Windows.Forms.Button btnRejt;
        private System.Windows.Forms.Button btnUj;
        private System.Windows.Forms.Button btnKilep;
    }
}

